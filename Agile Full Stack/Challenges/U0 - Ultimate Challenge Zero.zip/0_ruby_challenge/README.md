## Build a image
docker-compose up --build

## Switch to production
environment:
RACK_ENV: production

